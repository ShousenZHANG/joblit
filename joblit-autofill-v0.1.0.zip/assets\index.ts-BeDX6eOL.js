import{r as e}from"./i18n-DVRXAQYj.js";import{r as t}from"./constants-DO2yFCZV.js";var n=function(e){return e.FULL_NAME=`full_name`,e.FIRST_NAME=`first_name`,e.LAST_NAME=`last_name`,e.EMAIL=`email`,e.PHONE=`phone`,e.LOCATION=`location`,e.ADDRESS=`address`,e.CITY=`city`,e.STATE=`state`,e.ZIPCODE=`zipcode`,e.COUNTRY=`country`,e.LINKEDIN_URL=`linkedin_url`,e.GITHUB_URL=`github_url`,e.PORTFOLIO_URL=`portfolio_url`,e.WEBSITE_URL=`website_url`,e.CURRENT_COMPANY=`current_company`,e.CURRENT_TITLE=`current_title`,e.YEARS_EXPERIENCE=`years_experience`,e.DESIRED_SALARY=`desired_salary`,e.AVAILABILITY=`availability`,e.WORK_AUTHORIZATION=`work_authorization`,e.SPONSORSHIP_REQUIRED=`sponsorship_required`,e.SCHOOL_NAME=`school_name`,e.DEGREE=`degree`,e.MAJOR=`major`,e.GPA=`gpa`,e.GRADUATION_DATE=`graduation_date`,e.RESUME_UPLOAD=`resume_upload`,e.COVER_LETTER_UPLOAD=`cover_letter_upload`,e.COVER_LETTER_TEXT=`cover_letter_text`,e.ADDITIONAL_INFO=`additional_info`,e.SUMMARY=`summary`,e.WECHAT=`wechat`,e.QQ=`qq`,e.GENDER=`gender`,e.AGE=`age`,e.IDENTITY=`identity`,e.AGREE_TERMS=`agree_terms`,e.AGREE_PRIVACY=`agree_privacy`,e.UNKNOWN=`unknown`,e}({}),r={[n.FULL_NAME]:[/full\s*name/i,/your\s*name/i,/^name$/i,/applicant\s*name/i,/candidate\s*name/i,/姓名/,/全名/],[n.FIRST_NAME]:[/first\s*name/i,/given\s*name/i,/名$/,/^名字/],[n.LAST_NAME]:[/last\s*name/i,/family\s*name/i,/surname/i,/姓$/,/^姓氏/],[n.EMAIL]:[/e-?mail/i,/邮箱/,/电子邮件/,/邮件地址/],[n.PHONE]:[/phone/i,/mobile/i,/cell/i,/telephone/i,/手机/,/电话/,/联系方式/],[n.LOCATION]:[/^location$/i,/current\s*location/i,/所在地/,/所在城市/],[n.ADDRESS]:[/address/i,/street/i,/地址/,/住址/],[n.CITY]:[/^city$/i,/城市/],[n.STATE]:[/^state$/i,/province/i,/省份/,/州/],[n.ZIPCODE]:[/zip/i,/postal/i,/邮编/,/邮政编码/],[n.COUNTRY]:[/country/i,/国家/,/国籍/],[n.LINKEDIN_URL]:[/linkedin/i,/领英/],[n.GITHUB_URL]:[/github/i],[n.PORTFOLIO_URL]:[/portfolio/i,/作品集/],[n.WEBSITE_URL]:[/website/i,/personal\s*url/i,/blog/i,/个人网站/],[n.CURRENT_COMPANY]:[/current\s*company/i,/employer/i,/company\s*name/i,/当前公司/,/目前公司/,/所在公司/],[n.CURRENT_TITLE]:[/current\s*title/i,/job\s*title/i,/position/i,/当前职位/,/目前职位/],[n.YEARS_EXPERIENCE]:[/years?\s*(of\s*)?experience/i,/工作年限/,/工作经验/],[n.DESIRED_SALARY]:[/salary/i,/compensation/i,/薪资/,/期望薪酬/],[n.AVAILABILITY]:[/availab/i,/start\s*date/i,/when\s*can\s*you/i,/到岗时间/,/入职时间/],[n.WORK_AUTHORIZATION]:[/work\s*auth/i,/authorized?\s*to\s*work/i,/work\s*permit/i,/visa\s*status/i,/工作签证/],[n.SPONSORSHIP_REQUIRED]:[/sponsor/i,/visa\s*sponsor/i,/需要签证/],[n.SCHOOL_NAME]:[/school/i,/university/i,/college/i,/institution/i,/学校/,/院校/,/大学/],[n.DEGREE]:[/degree/i,/qualification/i,/学历/,/学位/],[n.MAJOR]:[/major/i,/field\s*of\s*study/i,/专业/],[n.GPA]:[/gpa/i,/grade/i,/绩点/,/成绩/],[n.GRADUATION_DATE]:[/graduat/i,/毕业/],[n.RESUME_UPLOAD]:[/resume/i,/cv\b/i,/简历/],[n.COVER_LETTER_UPLOAD]:[/cover\s*letter/i,/求职信/],[n.COVER_LETTER_TEXT]:[/cover\s*letter/i,/求职信/],[n.ADDITIONAL_INFO]:[/additional/i,/anything\s*else/i,/补充/,/其他/],[n.SUMMARY]:[/summary/i,/about\s*(you|yourself)/i,/自我介绍/,/个人简介/],[n.WECHAT]:[/wechat/i,/微信/],[n.QQ]:[/\bqq\b/i],[n.GENDER]:[/gender/i,/sex/i,/性别/],[n.AGE]:[/\bage\b/i,/年龄/],[n.IDENTITY]:[/ethnic/i,/race/i,/民族/,/种族/],[n.AGREE_TERMS]:[/agree.*terms/i,/terms.*conditions/i,/accept.*terms/i,/同意.*条款/,/i\s*agree/i],[n.AGREE_PRIVACY]:[/privacy/i,/data.*consent/i,/隐私/],[n.UNKNOWN]:[]},i={[n.FULL_NAME]:`fullName`,[n.FIRST_NAME]:`firstName`,[n.LAST_NAME]:`lastName`,[n.EMAIL]:`email`,[n.PHONE]:`phone`,[n.LOCATION]:`location`,[n.CURRENT_TITLE]:`currentTitle`,[n.CURRENT_COMPANY]:`currentCompany`,[n.LINKEDIN_URL]:`linkedinUrl`,[n.GITHUB_URL]:`githubUrl`,[n.PORTFOLIO_URL]:`portfolioUrl`,[n.WEBSITE_URL]:`websiteUrl`,[n.SCHOOL_NAME]:`schoolName`,[n.DEGREE]:`degree`,[n.GRADUATION_DATE]:`graduationDates`,[n.SUMMARY]:`summary`,[n.WECHAT]:`wechat`,[n.QQ]:`qq`,[n.GENDER]:`gender`,[n.AGE]:`age`,[n.IDENTITY]:`identity`,[n.AVAILABILITY]:`availabilityMonth`,[n.WORK_AUTHORIZATION]:`workAuthorization`,[n.SPONSORSHIP_REQUIRED]:`sponsorshipRequired`,[n.YEARS_EXPERIENCE]:`yearsExperience`,[n.DESIRED_SALARY]:`desiredSalary`,[n.AGREE_TERMS]:`agreeTerms`,[n.AGREE_PRIVACY]:`agreePrivacy`},a={nameId:.3,label:.35,placeholder:.15,aria:.1,adjacentText:.1};function o(e){return e.trim().replace(/\s+/g,` `)}function s(e){return typeof CSS<`u`&&CSS.escape?CSS.escape(e):e.replace(/([^\w-])/g,`\\$1`)}function c(e){if(e.id){let t=e.ownerDocument.querySelector(`label[for="${s(e.id)}"]`);if(t?.textContent)return o(t.textContent)}let t=e.closest(`label`);if(t?.textContent)return o(t.textContent);let n=e.getAttribute(`aria-label`);if(n)return o(n);let r=e.getAttribute(`aria-describedby`);if(r){let t=e.ownerDocument.getElementById(r);if(t?.textContent)return o(t.textContent)}return``}function l(e){let t=e.previousElementSibling;if(t?.textContent&&t.tagName!==`INPUT`)return o(t.textContent);let n=e.parentElement;if(n){for(let e of n.childNodes)if(e.nodeType===Node.TEXT_NODE&&e.textContent?.trim())return o(e.textContent)}return``}function u(e,t){let n=r[t];return!n.length||!e?0:n.some(t=>t.test(e))?1:0}function d(e){let t=e.getAttribute(`name`)??``,r=e.id??``,i=e.placeholder??``,o=e.getAttribute(`aria-label`)??``,s=c(e),d=l(e),f=n.UNKNOWN,p=0;for(let e of Object.values(n)){if(e===n.UNKNOWN)continue;let c=Math.max(u(t,e),u(r,e)),l=u(s,e),m=u(i,e),h=u(o,e),g=u(d,e),_=c*a.nameId+l*a.label+m*a.placeholder+h*a.aria+g*a.adjacentText;_>p&&(p=_,f=e)}return{category:f,confidence:p,labelText:s||i||t||r}}function f(e){if(e.id)return`#${s(e.id)}`;let t=e.getAttribute(`name`);if(t)return`[name="${s(t)}"]`;let n=e.tagName.toLowerCase(),r=e.parentElement;return r?`${n}:nth-of-type(${Array.from(r.children).filter(t=>t.tagName===e.tagName).indexOf(e)+1})`:n}function p(e){return e.tagName===`SELECT`?`select`:e.tagName===`TEXTAREA`?`textarea`:e.getAttribute(`contenteditable`)===`true`?`contenteditable`:e.type??`text`}var m={name:`greenhouse`,canHandle(e,t){return/boards\.greenhouse\.io|\.greenhouse\.io\/.*\/jobs/i.test(e)},detectFields(e){let t=e.getElementById(`application_form`)??e.querySelector(`.application-form`);if(!t)return[];let n=t.querySelectorAll(`input:not([type=hidden]):not([type=submit]), textarea, select`),r=[];for(let e of n){let t=p(e),{category:n,confidence:i,labelText:a}=d(e);r.push({element:e,selector:f(e),inputType:t,category:n,confidence:i,labelText:a,name:e.getAttribute(`name`)??``,id:e.id??``,placeholder:e.placeholder??``})}return r}},h={name:`lever`,canHandle(e,t){return/jobs\.lever\.co/i.test(e)},detectFields(e){let t=e.querySelector(`[data-qa="application-form"]`)??e.querySelector(`.application-form`)??e.querySelector(`.postings-btn-wrapper`)?.closest(`form`);if(!t)return[];let n=t.querySelectorAll(`input:not([type=hidden]):not([type=submit]):not([type=button]), textarea, select`),r=[];for(let e of n){let t=p(e),{category:n,confidence:i,labelText:a}=d(e);r.push({element:e,selector:f(e),inputType:t,category:n,confidence:i,labelText:a,name:e.getAttribute(`name`)??``,id:e.id??``,placeholder:e.placeholder??``})}return r}},g={name:`workday`,canHandle(e,t){return/myworkdayjobs\.com|\.wd[0-9]+\.myworkdayjobs\.com|workday\.com\/.*\/job/i.test(e)},detectFields(e){let t=e.querySelector(`[data-automation-id="jobApplicationContainer"]`)??e.querySelector(`[data-automation-id="applyForm"]`)??e.querySelector(`.css-1bfq2lx`);if(!t)return[];let n=t.querySelectorAll([`input:not([type=hidden]):not([type=submit]):not([type=button])`,`textarea`,`select`,`[data-automation-id$="Input"]`,`[data-automation-id$="Dropdown"]`,`[role="combobox"]`,`[role="listbox"]`].join(`, `)),r=new Set,i=[];for(let e of n){let t=e.tagName===`INPUT`||e.tagName===`TEXTAREA`||e.tagName===`SELECT`?e:e.querySelector(`input, textarea, select`)??e;if(r.has(t))continue;r.add(t);let n=p(t),{category:a,confidence:o,labelText:s}=d(t);i.push({element:t,selector:f(t),inputType:n,category:a,confidence:o,labelText:s,name:t.getAttribute(`name`)??``,id:t.id??``,placeholder:t.placeholder??``})}return i}},_={name:`icims`,canHandle(e,t){return/icims\.com|\.icims\./i.test(e)?!0:!!t.querySelector(`meta[name="generator"][content*="iCIMS"]`)},detectFields(e){let t=e.querySelector(`.iCIMS_Forms`)??e.querySelector(`[class*="iCIMS"]`)??e.querySelector(`form[action*="icims"]`);if(!t)return[];let n=t.querySelectorAll(`input:not([type=hidden]):not([type=submit]):not([type=button]), textarea, select`),r=[];for(let e of n){let t=p(e),{category:n,confidence:i,labelText:a}=d(e);r.push({element:e,selector:f(e),inputType:t,category:n,confidence:i,labelText:a,name:e.getAttribute(`name`)??``,id:e.id??``,placeholder:e.placeholder??``})}return r}},ee={name:`successfactors`,canHandle(e,t){return/successfactors\.com|\.successfactors\.|sap\.com\/.*career/i.test(e)},detectFields(e){let t=e.querySelector(`#applyFormContainer`)??e.querySelector(`[data-automation-id="applyForm"]`)??e.querySelector(`form[name="applyForm"]`);if(!t)return[];let n=t.querySelectorAll(`input:not([type=hidden]):not([type=submit]):not([type=button]), textarea, select`),r=[];for(let e of n){let t=p(e),{category:n,confidence:i,labelText:a}=d(e);r.push({element:e,selector:f(e),inputType:t,category:n,confidence:i,labelText:a,name:e.getAttribute(`name`)??``,id:e.id??``,placeholder:e.placeholder??``})}return r}},te=/taleo\.net|oracle.*careers|oracle.*recruit/i,ne={name:`taleo`,canHandle(e){return te.test(e)},detectFields(e){let t=e.querySelector(`#requisitionDescriptionInterface`)??e.querySelector(`[class*="applicationForm"]`)??e.querySelector(`form`);if(!t)return[];let n=t.querySelectorAll(`input, textarea, select, [contenteditable='true']`),r=[];for(let e of n){if(e instanceof HTMLInputElement&&[`hidden`,`submit`,`button`,`reset`,`image`].includes(e.type))continue;let{category:t,confidence:n,labelText:i}=d(e);r.push({element:e,selector:f(e),inputType:p(e),category:t,confidence:n,labelText:i,name:e.name??``,id:e.id??``,placeholder:e.placeholder??``})}return r}},re=/smartrecruiters\.com/i,ie={name:`smartRecruiters`,canHandle(e){return re.test(e)},detectFields(e){let t=e.querySelector(`.application-form`)??e.querySelector(`[data-test="application-form"]`)??e.querySelector(`form`);if(!t)return[];let n=t.querySelectorAll(`input, textarea, select, [contenteditable='true']`),r=[];for(let e of n){if(e instanceof HTMLInputElement&&[`hidden`,`submit`,`button`,`reset`,`image`].includes(e.type))continue;let{category:t,confidence:n,labelText:i}=d(e);r.push({element:e,selector:f(e),inputType:p(e),category:t,confidence:n,labelText:i,name:e.name??``,id:e.id??``,placeholder:e.placeholder??``})}return r}},ae=/bamboohr\.com.*careers/i,oe={name:`bamboohr`,canHandle(e){return ae.test(e)},detectFields(e){let t=e.querySelector(`#applicationForm`)??e.querySelector(`.BambooHR-ATS-board form`)??e.querySelector(`form`);if(!t)return[];let n=t.querySelectorAll(`input, textarea, select, [contenteditable='true']`),r=[];for(let e of n){if(e instanceof HTMLInputElement&&[`hidden`,`submit`,`button`,`reset`,`image`].includes(e.type))continue;let{category:t,confidence:n,labelText:i}=d(e);r.push({element:e,selector:f(e),inputType:p(e),category:t,confidence:n,labelText:i,name:e.name??``,id:e.id??``,placeholder:e.placeholder??``})}return r}},se=/jobvite\.com/i,ce={name:`jobvite`,canHandle(e){return se.test(e)},detectFields(e){let t=e.querySelector(`.jv-application`)??e.querySelector(`.jv-job-detail-apply form`)??e.querySelector(`form`);if(!t)return[];let n=t.querySelectorAll(`input, textarea, select, [contenteditable='true']`),r=[];for(let e of n){if(e instanceof HTMLInputElement&&[`hidden`,`submit`,`button`,`reset`,`image`].includes(e.type))continue;let{category:t,confidence:n,labelText:i}=d(e);r.push({element:e,selector:f(e),inputType:p(e),category:t,confidence:n,labelText:i,name:e.name??``,id:e.id??``,placeholder:e.placeholder??``})}return r}},v=/ashbyhq\.com/i,y={name:`ashby`,canHandle(e){return v.test(e)},detectFields(e){let t=e.querySelector(`[data-testid="application-form"]`)??e.querySelector(`.ashby-application-form`)??e.querySelector(`form`);if(!t)return[];let n=t.querySelectorAll(`input, textarea, select, [contenteditable='true']`),r=[];for(let e of n){if(e instanceof HTMLInputElement&&[`hidden`,`submit`,`button`,`reset`,`image`].includes(e.type))continue;let{category:t,confidence:n,labelText:i}=d(e);r.push({element:e,selector:f(e),inputType:p(e),category:t,confidence:n,labelText:i,name:e.name??``,id:e.id??``,placeholder:e.placeholder??``})}return r}},b=/rippling\.com.*careers/i,x={name:`rippling`,canHandle(e){return b.test(e)},detectFields(e){let t=e.querySelector(`[data-testid="application-form"]`)??e.querySelector(`.application-form`)??e.querySelector(`form`);if(!t)return[];let n=t.querySelectorAll(`input, textarea, select, [contenteditable='true']`),r=[];for(let e of n){if(e instanceof HTMLInputElement&&[`hidden`,`submit`,`button`,`reset`,`image`].includes(e.type))continue;let{category:t,confidence:n,labelText:i}=d(e);r.push({element:e,selector:f(e),inputType:p(e),category:t,confidence:n,labelText:i,name:e.name??``,id:e.id??``,placeholder:e.placeholder??``})}return r}},S={name:`generic`,canHandle(e,t){return!0},detectFields(){return[]}},C=[m,h,g,_,ee,ne,ie,oe,ce,y,x,S];function le(e){let t=e.location?.href??``;for(let n of C)if(n.canHandle(t,e))return n;return S}var ue=new Set([`hidden`,`submit`,`button`,`reset`,`image`]),de=`input, textarea, select, [contenteditable='true']`;function fe(e){if(e.getAttribute(`aria-hidden`)===`true`||e instanceof HTMLInputElement&&e.type===`hidden`)return!1;let t=typeof getComputedStyle==`function`,n=t?getComputedStyle(e):e.style;return!(n.display===`none`||n.visibility===`hidden`||t&&parseFloat(n.opacity)===0||e.offsetParent!==void 0&&e.offsetParent===null&&n.position!==`fixed`&&n.position!==`sticky`&&n.display!==``)}function pe(e,t){let n=t.detectFields(e);if(n.length>0)return n;let r=e.querySelectorAll(de),i=[];for(let e of r){let t=p(e);if(ue.has(t)||!fe(e)||e.disabled||e.readOnly||e.getAttribute(`aria-disabled`)===`true`)continue;let{category:n,confidence:r,labelText:a}=d(e);i.push({element:e,selector:f(e),inputType:t,category:n,confidence:r,labelText:a,name:e.getAttribute(`name`)??``,id:e.id??``,placeholder:e.placeholder??``})}return i}function w(e){let t=le(e),n=pe(e,t),r=Array.from(e.querySelectorAll(`form`));return{atsProvider:t.name,fields:n,forms:r}}function T(){return Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,`value`)?.set}function E(){return Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,`value`)?.set}function D(e,t){if(e instanceof HTMLInputElement){let n=T();n?n.call(e,t):e.value=t}else if(e instanceof HTMLTextAreaElement){let n=E();n?n.call(e,t):e.value=t}else if(e.getAttribute(`contenteditable`)===`true`)e.textContent=t;else return;e.dispatchEvent(new FocusEvent(`focus`,{bubbles:!0})),e.dispatchEvent(new InputEvent(`input`,{bubbles:!0,inputType:`insertText`,data:t})),e.dispatchEvent(new Event(`change`,{bubbles:!0})),e.dispatchEvent(new FocusEvent(`blur`,{bubbles:!0}))}function O(e,t){let n=Array.from(e.options),r=t.toLowerCase().trim(),i=n.find(e=>e.value===t)??n.find(e=>e.textContent?.trim().toLowerCase()===r)??n.find(e=>e.textContent?.trim().toLowerCase().includes(r));return i?(e.value=i.value,e.dispatchEvent(new Event(`change`,{bubbles:!0})),!0):!1}function k(e,t){let n=t.toLowerCase().trim(),r=e.find(e=>e.value.toLowerCase()===n)??e.find(e=>{let t=e.labels?.[0]?.textContent?.trim().toLowerCase()??e.parentElement?.textContent?.trim().toLowerCase()??``;return t===n||t.includes(n)});return r?(r.checked=!0,r.dispatchEvent(new Event(`change`,{bubbles:!0})),r.dispatchEvent(new Event(`click`,{bubbles:!0})),!0):!1}function A(e,t){e.checked!==t&&(e.checked=t,e.dispatchEvent(new Event(`change`,{bubbles:!0})),e.dispatchEvent(new Event(`click`,{bubbles:!0})))}async function j(e,t){let n=[200,500,1e3],r=t.toLowerCase().trim(),i=[`[role="option"]`,`[role="menuitem"]`,`li[data-value]`,`.option`,`[class*="option"]`,`[class*="Option"]`];for(let t of n){e.focus(),e.dispatchEvent(new MouseEvent(`mousedown`,{bubbles:!0})),e.click(),await new Promise(e=>setTimeout(e,t));for(let t of i){let n=document.querySelectorAll(t);for(let t of n){let n=(t.textContent??``).trim().toLowerCase(),i=t.dataset.value?.toLowerCase();if(n===r||i===r||n.includes(r))return t.click(),e.dispatchEvent(new Event(`change`,{bubbles:!0})),!0}}}return!1}var M=typeof CSS<`u`&&CSS.escape?e=>CSS.escape(e):e=>e.replace(/([^\w-])/g,`\\$1`),N=.15;function P(e,t,r){let a={filled:0,skipped:0,fields:[]};for(let o of e){if(o.inputType===`file`){a.skipped++,a.fields.push({selector:o.selector,category:o.category,value:``,filled:!1,source:`skipped`});continue}let e=r?.[o.selector];if(e){let t=F(o,e);a.fields.push({selector:o.selector,category:o.category,value:e,filled:t,source:`historical`}),t?a.filled++:a.skipped++;continue}let s=i[o.category],c=s?t[s]??``:``;if(!c||o.confidence<N||o.category===n.UNKNOWN){a.skipped++,a.fields.push({selector:o.selector,category:o.category,value:``,filled:!1,source:`skipped`});continue}let l=F(o,c);a.fields.push({selector:o.selector,category:o.category,value:c,filled:l,source:`profile`}),l?a.filled++:a.skipped++}return a}function F(e,t){let n=e.selector?document.querySelector(e.selector)??e.element:e.element;if(n.disabled||n.readOnly||n.getAttribute(`aria-disabled`)===`true`)return!1;if(n.getAttribute(`role`)===`combobox`||n.getAttribute(`role`)===`listbox`||n.dataset?.automationId?.includes(`Dropdown`))return j(n,t),!0;if(n instanceof HTMLSelectElement)return O(n,t);if(n instanceof HTMLInputElement&&n.type===`radio`){let e=n.name;if(!e)return!1;let r=n.closest(`form`)??n.ownerDocument;return k(Array.from(r.querySelectorAll(`input[type="radio"][name="${M(e)}"]`)),t)}return n instanceof HTMLInputElement&&n.type===`checkbox`?(A(n,[`true`,`yes`,`1`,`on`].includes(t.toLowerCase().trim())),!0):(D(n,t),!0)}function I(e){let t=[`button[data-automation-id="bottom-navigation-next-button"]`,`button[data-testid="next-button"]`,`button[type="button"]`,`a.btn`,`button`],n=/^(next|continue|proceed|save\s*(?:&|and)\s*continue|save\s*&\s*next|下一步|继续|保存并继续)$/i,r=/^(submit|apply|投递|提交申请|submit\s*application|apply\s*now)$/i;for(let i of t){let t=e.querySelectorAll(i);for(let e of t){let t=e.textContent?.trim()??``;if(r.test(t))return!1;if(n.test(t))return e.click(),!0}}return!1}function L(e){let t=`joblit-unfilled-highlight`,n=`joblit-highlight-style`;if(!document.getElementById(n)){let e=document.createElement(`style`);e.id=n,e.textContent=`
      .${t} {
        outline: 2px solid #f59e0b !important;
        outline-offset: 2px !important;
        background-color: rgba(245, 158, 11, 0.05) !important;
        transition: outline-color 0.3s ease !important;
      }
      .${t}:focus {
        outline-color: #22c55e !important;
        background-color: transparent !important;
      }
    `,document.head.appendChild(e)}let r=[];for(let n of e){let e=n.selector?document.querySelector(n.selector):null;e&&((e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement||e instanceof HTMLSelectElement?e.value:e.textContent??``).trim()||(e.classList.add(t),r.push(e)))}return()=>{for(let e of r)e.classList.remove(t);let e=document.getElementById(n);e&&e.remove()}}function R(e,t=1e4){return new Promise(n=>{let r=setTimeout(()=>{n({success:!1,error:`Request timed out`})},t);chrome.runtime.sendMessage(e,e=>{if(clearTimeout(r),chrome.runtime.lastError){n({success:!1,error:chrome.runtime.lastError.message??`Unknown error`});return}n(e)})})}var z=`joblit-autofill-widget`;function B(){if(document.getElementById(z))return null;let e=document.createElement(`div`);e.id=z,e.style.cssText=`all: initial; position: fixed; z-index: 2147483647;`,document.body.appendChild(e);let t=e.attachShadow({mode:`open`}),n=document.createElement(`style`);n.textContent=ge(),t.appendChild(n);let r=document.createElement(`div`);return r.id=`joblit-widget-root`,t.appendChild(r),chrome.storage.local.get(`widgetPosition`,e=>{let t=e.widgetPosition;t?.right&&t?.bottom&&(r.style.right=t.right,r.style.bottom=t.bottom)}),{shadowRoot:t,container:r}}function me(){let e=document.getElementById(z);e&&e.remove()}function he(){return!!document.getElementById(z)}function ge(){return`
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    }

    #joblit-widget-root {
      position: fixed;
      bottom: 20px;
      right: 20px;
      width: 320px;
      max-height: 480px;
      background: #fff;
      border-radius: 14px;
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.12), 0 2px 8px rgba(0, 0, 0, 0.06);
      overflow: hidden;
      font-size: 13px;
      color: #1a1a1a;
      transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
    }

    /* ── Header ── */
    .jf-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 12px 14px;
      background: linear-gradient(135deg, #10b981, #047857);
      color: #fff;
    }

    .jf-header-left {
      display: flex;
      align-items: center;
      gap: 6px;
    }

    .jf-header-logo-icon {
      display: flex;
      align-items: center;
      opacity: 0.9;
    }

    .jf-header-title {
      font-weight: 700;
      font-size: 14px;
      letter-spacing: -0.2px;
    }

    .jf-header-badge {
      background: rgba(255, 255, 255, 0.2);
      padding: 2px 8px;
      border-radius: 10px;
      font-size: 11px;
      font-weight: 600;
    }

    .jf-header-actions {
      display: flex;
      gap: 4px;
    }

    .jf-header-btn {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 26px;
      height: 26px;
      background: rgba(255, 255, 255, 0.1);
      border: none;
      border-radius: 6px;
      color: #fff;
      cursor: pointer;
      opacity: 0.8;
      transition: all 150ms ease;
    }

    .jf-header-btn:hover {
      opacity: 1;
      background: rgba(255, 255, 255, 0.2);
    }

    /* ── Fill progress ── */
    .jf-fill-progress {
      height: 3px;
      background: rgba(0, 0, 0, 0.05);
      overflow: hidden;
    }

    .jf-fill-progress-bar {
      height: 100%;
      border-radius: 2px;
      transition: width 300ms cubic-bezier(0.4, 0, 0.2, 1);
    }

    .jf-fill-progress-bar--active {
      background: #10b981;
    }

    .jf-fill-progress-bar--done {
      background: #10b981;
    }

    /* ── Body ── */
    .jf-body {
      padding: 10px 14px;
      max-height: 340px;
      overflow-y: auto;
    }

    .jf-field-list {
      list-style: none;
    }

    .jf-field-item {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 7px 0;
      border-bottom: 1px solid #f3f4f6;
      transition: background 100ms ease;
    }

    .jf-field-item:last-child {
      border-bottom: none;
    }

    .jf-field-item:hover {
      background: #f9fafb;
      margin: 0 -14px;
      padding-left: 14px;
      padding-right: 14px;
    }

    .jf-field-label {
      font-size: 12px;
      color: #6b7280;
      max-width: 100px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      flex-shrink: 0;
    }

    .jf-field-value {
      font-size: 12px;
      color: #111827;
      font-weight: 500;
      max-width: 150px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      margin-left: auto;
    }

    .jf-confidence {
      width: 7px;
      height: 7px;
      border-radius: 50%;
      flex-shrink: 0;
    }

    .jf-confidence-high { background: #10b981; box-shadow: 0 0 0 2px rgba(16, 185, 129, 0.15); }
    .jf-confidence-medium { background: #f59e0b; }
    .jf-confidence-low { background: #d1d5db; }

    /* ── Footer ── */
    .jf-footer {
      padding: 10px 14px;
      border-top: 1px solid #f3f4f6;
      display: flex;
      gap: 8px;
    }

    .jf-btn-primary {
      flex: 1;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      padding: 9px 16px;
      background: #059669;
      color: #fff;
      border: none;
      border-radius: 8px;
      font-size: 13px;
      font-weight: 600;
      cursor: pointer;
      transition: all 150ms ease;
    }

    .jf-btn-primary:hover { background: #047857; box-shadow: 0 2px 8px rgba(5, 150, 105, 0.3); }
    .jf-btn-primary:active { transform: scale(0.97); }

    .jf-btn-secondary {
      display: inline-flex;
      align-items: center;
      padding: 9px 14px;
      background: #f8fafc;
      color: #475569;
      border: 1.5px solid #e5e7eb;
      border-radius: 8px;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
      transition: all 150ms ease;
    }

    .jf-btn-secondary:hover { background: #f1f5f9; border-color: #d1d5db; }
    .jf-btn-secondary:active { transform: scale(0.97); }

    .jf-footer-actions {
      display: flex;
      gap: 8px;
      width: 100%;
    }
    .jf-footer-actions .jf-btn-primary { flex: 1; }
    .jf-footer-actions .jf-btn-secondary { flex-shrink: 0; }

    /* ── Collapsed badge ── */
    .jf-collapsed {
      width: 48px;
      height: 48px;
      border-radius: 14px;
      background: linear-gradient(135deg, #10b981, #047857);
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      position: fixed;
      bottom: 20px;
      right: 20px;
      box-shadow: 0 4px 16px rgba(5, 150, 105, 0.35);
      transition: all 200ms cubic-bezier(0.34, 1.56, 0.64, 1);
    }

    .jf-collapsed:hover {
      transform: scale(1.08);
      box-shadow: 0 6px 20px rgba(5, 150, 105, 0.4);
    }

    .jf-collapsed:active {
      transform: scale(0.95);
    }

    .jf-collapsed--has-fields {
      animation: jf-pulse 2.5s ease infinite;
    }

    .jf-collapsed-badge {
      position: absolute;
      top: -5px;
      right: -5px;
      background: #fff;
      color: #059669;
      font-size: 10px;
      font-weight: 700;
      min-width: 18px;
      height: 18px;
      padding: 0 4px;
      border-radius: 9px;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 1px 4px rgba(0, 0, 0, 0.15);
    }

    .jf-logo {
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .jf-empty {
      text-align: center;
      padding: 24px;
      color: #9ca3af;
      font-size: 13px;
    }

    /* ── Review bar ── */
    .jf-review-bar {
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 6px 14px;
      background: #ecfdf5;
      border-bottom: 1px solid #d1fae5;
      font-size: 11px;
      font-weight: 500;
      color: #047857;
    }

    /* ── Status dots ── */
    .jf-dot-filled { background: #10b981; box-shadow: 0 0 0 2px rgba(16, 185, 129, 0.15); }
    .jf-dot-edited { background: #f59e0b; box-shadow: 0 0 0 2px rgba(245, 158, 11, 0.15); }
    .jf-dot-unfilled { background: #d1d5db; }
    .jf-dot-unknown { background: #e5e7eb; border: 1.5px dashed #9ca3af; }

    /* ── Field value states ── */
    .jf-field-value--edited {
      color: #d97706;
      font-style: italic;
    }

    .jf-field-value--empty {
      color: #d1d5db;
      cursor: pointer;
    }

    .jf-field-value--empty:hover {
      color: #10b981;
    }

    /* ── Edit button (hover reveal) ── */
    .jf-edit-btn {
      display: none;
      align-items: center;
      justify-content: center;
      width: 22px;
      height: 22px;
      border: none;
      border-radius: 5px;
      background: #f3f4f6;
      color: #6b7280;
      cursor: pointer;
      flex-shrink: 0;
      margin-left: 4px;
      transition: all 100ms ease;
    }

    .jf-edit-btn:hover {
      background: #e5e7eb;
      color: #374151;
    }

    .jf-field-item:hover .jf-edit-btn {
      display: flex;
    }

    /* ── Inline edit ── */
    .jf-field-item--editing {
      background: #f9fafb;
      margin: 0 -14px;
      padding: 6px 14px;
      border-radius: 0;
    }

    .jf-edit-wrap {
      display: flex;
      align-items: center;
      gap: 4px;
      flex: 1;
      min-width: 0;
      margin-left: auto;
    }

    .jf-edit-input {
      flex: 1;
      min-width: 0;
      height: 26px;
      padding: 0 8px;
      border: 1.5px solid #10b981;
      border-radius: 6px;
      font-size: 12px;
      color: #111827;
      background: #fff;
      outline: none;
      box-shadow: 0 0 0 2px rgba(16, 185, 129, 0.1);
    }

    .jf-edit-input::placeholder {
      color: #d1d5db;
    }

    .jf-edit-confirm, .jf-edit-cancel {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 22px;
      height: 22px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      flex-shrink: 0;
      transition: all 100ms ease;
    }

    .jf-edit-confirm {
      background: #ecfdf5;
      color: #059669;
    }

    .jf-edit-confirm:hover {
      background: #d1fae5;
    }

    .jf-edit-cancel {
      background: #fef2f2;
      color: #dc2626;
    }

    .jf-edit-cancel:hover {
      background: #fecaca;
    }

    /* ── Toast ── */
    .jf-toast {
      position: absolute;
      bottom: 60px;
      left: 50%;
      transform: translateX(-50%);
      background: #065f46;
      color: #fff;
      font-size: 11px;
      font-weight: 500;
      padding: 6px 14px;
      border-radius: 8px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
      white-space: nowrap;
      animation: jf-toast-in 200ms ease, jf-toast-out 300ms ease 1.7s forwards;
      z-index: 10;
    }

    @keyframes jf-toast-in {
      from { opacity: 0; transform: translateX(-50%) translateY(8px); }
      to   { opacity: 1; transform: translateX(-50%) translateY(0); }
    }

    @keyframes jf-toast-out {
      from { opacity: 1; }
      to   { opacity: 0; }
    }

    /* ── Animations ── */
    @keyframes jf-pulse {
      0%, 100% { box-shadow: 0 4px 16px rgba(5, 150, 105, 0.35); }
      50%      { box-shadow: 0 4px 16px rgba(5, 150, 105, 0.35), 0 0 0 6px rgba(16, 185, 129, 0); }
    }

    @media (prefers-reduced-motion: reduce) {
      *, *::before, *::after {
        animation-duration: 0.01ms !important;
        transition-duration: 0.01ms !important;
      }
    }
  `}function _e(e,t){if(!e.trim())return null;let n=e.trim().toLowerCase();for(let[e,r]of Object.entries(t))if(r&&r.trim().toLowerCase()===n)return{profilePath:e,confidence:1};if(n.length>=5)for(let[e,r]of Object.entries(t)){if(!r)continue;let t=r.trim().toLowerCase();if(t.includes(n)||n.includes(t))return{profilePath:e,confidence:.7}}return null}var ve=class{root;collapsed=!0;fields=[];profile={};callbacks;fillProgress={filled:0,total:0,status:`idle`};mode=`browse`;edits=new Map;editingField=null;fillResults=new Map;atsProvider=``;pageDomain=``;constructor(e,t){this.root=e,this.callbacks=t,this.pageDomain=window.location.hostname,this.render()}setFields(e){this.fields=e,this.render()}setProfile(e){this.profile=e??{},this.render()}setAtsProvider(e){this.atsProvider=e}setFillProgress(e,t,n){this.fillProgress={filled:e,total:t,status:n},n===`done`&&(this.mode=`review`),this.render()}setFillResults(e){this.fillResults=e,this.render()}toggle(){this.collapsed=!this.collapsed,this.render()}getMatchedCount(){return this.fields.filter(e=>e.category!==n.UNKNOWN&&e.confidence>.15).length}getFieldValue(e){let t=this.edits.get(e.selector);if(t)return t.value;let n=this.fillResults.get(e.selector);if(n?.filled&&n.value)return n.value;let r=i[e.category];return r?this.profile[r]??``:``}getFieldStatus(e){if(this.edits.has(e.selector))return`edited`;let t=this.fillResults.get(e.selector);if(t?.filled&&t.value)return`filled`;if(e.category===n.UNKNOWN||e.confidence<.15)return`unknown`;let r=i[e.category];return r&&(this.profile[r]??``)?`filled`:`unfilled`}getStatusDotClass(e){switch(e){case`filled`:return`jf-dot-filled`;case`edited`:return`jf-dot-edited`;case`unfilled`:return`jf-dot-unfilled`;default:return`jf-dot-unknown`}}render(){this.collapsed?this.renderCollapsed():this.renderExpanded()}logoSvg(e){return`<svg width="${e}" height="${e}" viewBox="0 0 24 24" fill="none">
      <circle cx="10.5" cy="10.5" r="5" stroke="white" stroke-width="2" fill="none"/>
      <line x1="14" y1="14" x2="18" y2="18" stroke="white" stroke-width="2" stroke-linecap="round"/>
      <path d="M8.5 10.5h4M10.5 8.5v4" stroke="white" stroke-width="1.5" stroke-linecap="round"/>
    </svg>`}renderCollapsed(){let e=this.getMatchedCount(),t=this.edits.size;this.root.replaceChildren(),this.root.style.width=``,this.root.style.maxHeight=``,this.root.style.background=``,this.root.style.borderRadius=``,this.root.style.boxShadow=``;let n=document.createElement(`div`);n.className=`jf-collapsed`;let r=document.createElement(`span`);r.className=`jf-logo`,r.innerHTML=this.logoSvg(22),n.appendChild(r);let i=e+t;if(i>0){let e=document.createElement(`span`);e.className=`jf-collapsed-badge`,e.textContent=String(i),n.appendChild(e),n.classList.add(`jf-collapsed--has-fields`)}let a=0,o=0,s=!1;n.addEventListener(`mousedown`,e=>{a=e.clientX,o=e.clientY,s=!1;let t=e=>{let t=e.clientX-a,n=e.clientY-o;if(!s&&Math.abs(t)+Math.abs(n)>3&&(s=!0),s){let r=document.getElementById(`joblit-autofill-widget`);if(!r)return;let i=r.getBoundingClientRect(),s=Math.max(0,window.innerWidth-i.right-t),c=Math.max(0,window.innerHeight-i.bottom-n);this.root.style.right=`${s}px`,this.root.style.bottom=`${c}px`,a=e.clientX,o=e.clientY}},n=()=>{if(document.removeEventListener(`mousemove`,t),document.removeEventListener(`mouseup`,n),!s)this.toggle();else{let e=this.root.style.right,t=this.root.style.bottom;chrome.storage.local.set({widgetPosition:{right:e,bottom:t}})}};document.addEventListener(`mousemove`,t),document.addEventListener(`mouseup`,n)}),this.root.appendChild(n)}renderExpanded(){this.root.replaceChildren(),this.root.style.width=`340px`,this.root.style.maxHeight=`520px`,this.root.style.background=`#fff`,this.root.style.borderRadius=`14px`,this.root.style.boxShadow=`0 8px 32px rgba(0,0,0,0.12), 0 2px 8px rgba(0,0,0,0.06)`;let t=this.getMatchedCount(),n=document.createElement(`div`);n.className=`jf-header`;let r=document.createElement(`div`);r.className=`jf-header-left`;let i=document.createElement(`span`);i.className=`jf-header-logo-icon`,i.innerHTML=this.logoSvg(16),r.appendChild(i);let a=document.createElement(`span`);a.className=`jf-header-title`,a.textContent=`Joblit`,r.appendChild(a);let o=document.createElement(`span`);o.className=`jf-header-badge`,o.textContent=this.mode===`review`?e(`widget.review`):`${t}/${this.fields.length}`,r.appendChild(o);let s=document.createElement(`div`);s.className=`jf-header-actions`;let c=document.createElement(`button`);c.className=`jf-header-btn`,c.title=`Minimize`,c.innerHTML=`<svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M3 7h8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>`,c.addEventListener(`click`,()=>this.toggle());let l=document.createElement(`button`);if(l.className=`jf-header-btn`,l.title=`Close`,l.innerHTML=`<svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M3.5 3.5l7 7M10.5 3.5l-7 7" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>`,l.addEventListener(`click`,()=>this.toggle()),s.append(c,l),n.append(r,s),this.root.appendChild(n),this.fillProgress.status!==`idle`){let e=document.createElement(`div`);e.className=`jf-fill-progress`;let t=document.createElement(`div`);if(t.className=`jf-fill-progress-bar`,this.fillProgress.status===`filling`){let e=this.fillProgress.total>0?Math.round(this.fillProgress.filled/this.fillProgress.total*100):0;t.style.width=`${e}%`,t.classList.add(`jf-fill-progress-bar--active`)}else t.style.width=`100%`,t.classList.add(`jf-fill-progress-bar--done`);e.appendChild(t),this.root.appendChild(e)}if(this.mode===`review`){let t=document.createElement(`div`);t.className=`jf-review-bar`,t.innerHTML=`<svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M2 6.5l2.5 2.5L10 3" stroke="#059669" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`;let n=document.createElement(`span`);n.textContent=e(`widget.reviewHint`),t.appendChild(n),this.root.appendChild(t)}let u=document.createElement(`div`);if(u.className=`jf-body`,this.fields.length===0){let t=document.createElement(`div`);t.className=`jf-empty`,t.textContent=e(`widget.noFields`),u.appendChild(t)}else{let e=document.createElement(`ul`);e.className=`jf-field-list`;for(let t of this.fields)e.appendChild(this.renderFieldItem(t));u.appendChild(e)}this.root.appendChild(u);let d=document.createElement(`div`);if(d.className=`jf-footer`,this.mode===`review`)if(this.edits.size>0){let t=document.createElement(`div`);t.className=`jf-footer-actions`;let n=document.createElement(`button`);n.className=`jf-btn-primary`,n.textContent=e(`widget.saveChanges`).replace(`{count}`,String(this.edits.size)),n.addEventListener(`click`,()=>this.saveAllEdits());let r=document.createElement(`button`);r.className=`jf-btn-secondary`,r.textContent=e(`widget.skip`),r.addEventListener(`click`,()=>{this.edits.clear(),this.render()}),t.append(n,r),d.appendChild(t)}else{let t=document.createElement(`button`);t.className=`jf-btn-primary`,t.textContent=e(`widget.looksGood`),t.addEventListener(`click`,()=>this.handleDone()),d.appendChild(t)}else{let t=document.createElement(`button`);t.className=`jf-btn-primary jf-fill-btn`;let n=document.createElement(`span`);n.innerHTML=`<svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M2 12l3-8h6l3 8M4.5 8h7" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`;let r=document.createElement(`span`);r.textContent=e(`widget.fillAll`),t.append(n,r),t.addEventListener(`click`,()=>this.callbacks.onFill()),d.appendChild(t)}if(this.root.appendChild(d),this.editingField){let e=this.root.querySelector(`.jf-edit-input`);e&&(e.focus(),e.setSelectionRange(e.value.length,e.value.length))}}renderFieldItem(t){let n=this.getFieldValue(t),r=this.getFieldStatus(t),i=this.editingField===t.selector,a=document.createElement(`li`);a.className=`jf-field-item ${i?`jf-field-item--editing`:``}`;let o=document.createElement(`span`);o.className=`jf-confidence ${this.getStatusDotClass(r)}`,o.title=r;let s=document.createElement(`span`);if(s.className=`jf-field-label`,s.title=t.labelText,s.textContent=t.labelText||t.name||`—`,i){let r=document.createElement(`div`);r.className=`jf-edit-wrap`;let i=document.createElement(`input`);i.className=`jf-edit-input`,i.type=`text`,i.value=n,i.placeholder=e(`widget.typeValue`),i.addEventListener(`keydown`,e=>{e.key===`Enter`?this.commitEdit(t,i.value):e.key===`Escape`&&(this.editingField=null,this.render())});let c=document.createElement(`button`);c.className=`jf-edit-confirm`,c.title=`Confirm`,c.innerHTML=`<svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M2 6.5l2.5 2.5L10 3" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`,c.addEventListener(`click`,()=>{this.commitEdit(t,i.value)});let l=document.createElement(`button`);l.className=`jf-edit-cancel`,l.title=`Cancel`,l.innerHTML=`<svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M3 3l6 6M9 3l-6 6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>`,l.addEventListener(`click`,()=>{this.editingField=null,this.render()}),r.append(i,c,l),a.append(o,s,r)}else{let i=document.createElement(`span`);i.className=`jf-field-value ${r===`edited`?`jf-field-value--edited`:``} ${r===`unknown`||r===`unfilled`?`jf-field-value--empty`:``}`,i.title=n||e(`widget.clickToAdd`),i.textContent=n||(r===`unknown`?`?`:`—`);let c=document.createElement(`button`);c.className=`jf-edit-btn`,c.title=e(`widget.edit`),c.innerHTML=`<svg width="11" height="11" viewBox="0 0 12 12" fill="none"><path d="M7.5 2l2.5 2.5L4 10.5H1.5V8L7.5 2z" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/></svg>`,c.addEventListener(`click`,e=>{e.stopPropagation(),this.editingField=t.selector,this.render()}),i.addEventListener(`click`,()=>{this.editingField=t.selector,this.render()});let l=this.fillResults.get(t.selector);if(l?.filled&&l.source&&l.source!==`skipped`){let e=document.createElement(`span`);e.className=`jf-source-badge`,l.source===`profile`?(e.style.cssText=`font-size:9px;padding:1px 4px;border-radius:4px;margin-left:4px;background:#f0fdf4;color:#065f46;border:1px solid #d1fae5;`,e.textContent=`profile`):l.source===`historical`&&(e.style.cssText=`font-size:9px;padding:1px 4px;border-radius:4px;margin-left:4px;background:#eff6ff;color:#1e40af;border:1px solid #bfdbfe;`,e.textContent=`historical`),a.append(o,s,i,e,c)}else a.append(o,s,i,c)}return a}commitEdit(e,t){let n=t.trim();n?(this.edits.set(e.selector,{value:n,source:`user`}),this.callbacks.onApplyValue(e.selector,n)):this.edits.delete(e.selector),this.editingField=null,this.render()}async saveAllEdits(){let t=Array.from(this.edits.entries());if(t.length===0)return;let n=0;for(let[e,r]of t){let t=this.fields.find(t=>t.selector===e);t&&await this.saveFieldRule(t,r.value)&&n++}n===t.length?this.showToast(e(`widget.allSaved`)):this.showToast(`${n}/${t.length} saved`),this.edits.clear(),this.render()}async saveFieldRule(e,t){let n=_e(t,this.profile),r={fieldSelector:e.selector,fieldLabel:e.labelText||e.name||``,profilePath:n?.profilePath??e.category,staticValue:n?void 0:t,atsProvider:this.atsProvider,pageDomain:this.pageDomain,scope:`ats`};return this.callbacks.onSaveRule(r)}showToast(e){let t=this.root.querySelector(`.jf-toast`);t&&t.remove();let n=document.createElement(`div`);n.className=`jf-toast`,n.textContent=e,this.root.appendChild(n),setTimeout(()=>n.remove(),2e3)}handleDone(){this.callbacks.onRecordSubmission(),this.mode=`browse`,this.fillProgress={filled:0,total:0,status:`idle`},this.render()}destroy(){this.root.replaceChildren()}};function V(e){return ye(e.map(e=>`${e.category}:${H(e.labelText)}:${e.inputType}`).sort().join(`|`))}function H(e){return e.toLowerCase().replace(/[^a-z0-9\u4e00-\u9fff]/g,``).trim()}function ye(e){let t=5381;for(let n=0;n<e.length;n++)t=(t<<5)+t+e.charCodeAt(n)|0;return(t>>>0).toString(16).padStart(8,`0`)}function be(e,t,n,r,i,a,o){let s=new Map;for(let t of e){let e=a.find(e=>e.fieldSelector===t.selector);if(e||=a.find(e=>e.fieldLabel&&H(e.fieldLabel)===H(t.labelText)),e||=a.find(e=>e.profilePath===t.category&&e.source===`user`),e){let n=o?o[e.profilePath]:``,r=e.staticValue??n??``;r&&s.set(t.selector,{fieldSelector:t.selector,value:r,source:`user_rule`,confidence:e.confidence})}}let c=i.find(e=>e.formSignature===t);if(c)for(let t of e){if(s.has(t.selector))continue;let e=t.name||t.id||t.selector,n=c.fieldValues[e];n&&s.set(t.selector,{fieldSelector:t.selector,value:n,source:`exact`,confidence:.95})}let l=i.filter(e=>e.formSignature!==t&&e.atsProvider===r&&e.pageDomain===n);for(let t of l)for(let n of e){if(s.has(n.selector))continue;let e=n.name||n.id||n.selector,r=t.fieldValues[e];r&&s.set(n.selector,{fieldSelector:n.selector,value:r,source:`same_ats_domain`,confidence:.8})}let u=i.filter(e=>e.atsProvider===r&&e.pageDomain!==n);for(let t of u)for(let n of e){if(s.has(n.selector))continue;let e=n.name||n.id||n.selector,r=t.fieldValues[e];r&&s.set(n.selector,{fieldSelector:n.selector,value:r,source:`same_ats`,confidence:.6})}return s}function xe(e){let t={};for(let n of e){let e=n.name||n.id||n.selector,r=n.element;r instanceof HTMLInputElement||r instanceof HTMLTextAreaElement||r instanceof HTMLSelectElement?t[e]=r.value:r.getAttribute(`contenteditable`)===`true`&&(t[e]=r.textContent??``)}return t}function Se(e){let t={};for(let n of e){let e=n.name||n.id||n.selector;t[e]={source:n.confidence>0?`profile`:`manual`,profilePath:n.category===`unknown`?void 0:n.category,confidence:n.confidence}}return t}function Ce(e){try{return new URL(e).hostname}catch{return``}}async function U(e,t){let n=xe(e),r=Se(e),i=V(e),a=window.location.href;await R({type:`RECORD_SUBMISSION`,data:{pageUrl:a,pageDomain:Ce(a),atsProvider:t,formSignature:i,fieldValues:n,fieldMappings:r}})}function we(e,t){let n=n=>{U(e,t).catch(()=>{})},r=document.querySelectorAll(`form`);for(let e of r)e.addEventListener(`submit`,n);return()=>{for(let e of r)e.removeEventListener(`submit`,n)}}var W=null,G=null,K=null,q=null,J=window!==window.top;function Y(e,t){let n;return()=>{clearTimeout(n),n=setTimeout(e,t)}}async function Te(){return new Promise(e=>{chrome.storage.local.get(t.PREFERENCES,n=>{let r=n[t.PREFERENCES];e({autoFill:r?.autoFill??!1,showWidget:r?.showWidget??!0})})})}function X(e){q?.(),q=we(e.fields,e.atsProvider)}async function Z(){let e=[/greenhouse\.io/i,/lever\.co/i,/myworkdayjobs\.com/i,/workday\.com/i,/icims\.com/i,/successfactors\.com/i,/taleo\.net/i,/smartrecruiters\.com/i,/bamboohr\.com/i,/jobvite\.com/i,/ashbyhq\.com/i,/rippling\.com/i,/careers|jobs|apply|application/i].some(e=>e.test(location.href));if(!document.querySelector(`input, textarea, select, form`)&&!e&&!J){let e=new MutationObserver(()=>{document.querySelector(`input, textarea, select, form`)&&(e.disconnect(),Z())});e.observe(document.body,{childList:!0,subtree:!0});return}let t=await Te();chrome.runtime.onMessage.addListener((e,t,n)=>{if(e.type===`TRIGGER_FILL`)return $().then(e=>{n({success:!0,...e})}).catch(e=>{n({success:!1,error:e instanceof Error?e.message:`Fill failed`,filled:0,skipped:0})}),!0;if(e.type===`TOGGLE_WIDGET`)return Ee(),n({success:!0}),!0});let n=t.autoFill,r=[500,1500,3e3,6e3],i=!1;for(let e of r){await new Promise(t=>setTimeout(t,e));let t=w(document);if(t.fields.length>0){G=t,J||Q(G),X(G),n&&await $(),i=!0;break}}i||(G=w(document));let a=window.location.href,o=Y(()=>{try{let e=window.location.href;e!==a&&(a=e,G=null,K=null);let t=w(document);if(t.fields.length>0){let e=new Set(t.fields.map(e=>e.selector)),n=new Set(G?.fields.map(e=>e.selector)??[]);(e.size!==n.size||[...e].some(e=>!n.has(e)))&&(G=t,W&&W.setFields(t.fields),X(t))}}catch{}},500);new MutationObserver(o).observe(document.body,{childList:!0,subtree:!0})}async function Q(e){let t=B();if(!t)return;W=new ve(t.container,{onFill:()=>$(),onRecordSubmission:()=>{G&&U(G.fields,G.atsProvider)},onCorrectMapping:(e,t)=>{R({type:`RECORD_SUBMISSION`,data:{type:`CORRECT_MAPPING`,fieldSelector:e,newProfilePath:t}})},onSaveRule:async e=>{let t=e.scope===`global`?``:e.atsProvider,n=e.scope===`site`?e.pageDomain:``;return(await R({type:`PUT_FIELD_MAPPING`,data:{fieldSelector:e.fieldSelector,fieldLabel:e.fieldLabel,profilePath:e.profilePath,staticValue:e.staticValue||void 0,atsProvider:t,pageDomain:n,source:`user`}})).success},onApplyValue:(e,t)=>{let n=G?.fields.find(t=>t.selector===e);n?.element&&D(n.element,t)}}),W.setFields(e.fields),W.setAtsProvider(e.atsProvider);let n=await R({type:`GET_FLAT_PROFILE`});n.success&&n.data?.flat&&(K=n.data.flat,W.setProfile(K))}function Ee(){he()?W?W.toggle():me():((!G||G.fields.length===0)&&(G=w(document)),G.fields.length>0&&(J||Q(G),W&&W.toggle()))}async function De(e,t){let n={},r=window.location.hostname,i=V(e);try{let[a,o]=await Promise.all([R({type:`GET_SUBMISSIONS`,params:{atsProvider:t,pageDomain:r,limit:20}}),R({type:`GET_FIELD_MAPPINGS`,params:{atsProvider:t}})]),s=Array.isArray(a.data)?a.data:[],c=Array.isArray(o.data)?o.data:[];if(s.length===0&&c.length===0)return n;let l=be(e,i,r,t,s,c,K);for(let[e,t]of l)n[e]=t.value}catch{}return n}async function $(){if(G=w(document),G.fields.length===0&&(await new Promise(e=>setTimeout(e,1e3)),G=w(document)),G.fields.length===0)return{filled:0,skipped:0,message:`No form fields detected on this page.`};let e=await R({type:`GET_FLAT_PROFILE`});if(!e.success||!e.data?.flat)return{filled:0,skipped:0,message:`Could not load profile. Please check your connection.`};K=e.data.flat;let n=await De(G.fields,G.atsProvider),r={...await new Promise(e=>{chrome.storage.local.get(t.DEFAULT_ANSWERS,n=>{e(n[t.DEFAULT_ANSWERS]??{})})}),...K};W&&W.setFillProgress(0,G.fields.length,`filling`);let i=P(G.fields,r,n),a=L(G.fields);if(setTimeout(a,3e4),W){let e=new Map;for(let t of i.fields)e.set(t.selector,{filled:t.filled,source:t.source,value:t.value});W.setFillResults(e),W.setFillProgress(i.filled,G.fields.length,`done`),W.setFields(G.fields),setTimeout(()=>{W&&W.setFillProgress(0,0,`idle`)},3e3)}return i.filled>0&&setTimeout(()=>{I(document)&&setTimeout(()=>{G=w(document),G.fields.length>0&&$().catch(()=>{})},1500)},500),{...i,atsProvider:G.atsProvider,totalDetected:G.fields.length,message:`Filled ${i.filled} of ${G.fields.length} fields (${G.atsProvider}).`}}Z();